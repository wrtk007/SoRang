CREATE TABLE IF NOT EXISTS `team15`.`Origin_box` (
    `no` INT(5) NOT NULL AUTO_INCREMENT,
    `origin` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`no`)
)