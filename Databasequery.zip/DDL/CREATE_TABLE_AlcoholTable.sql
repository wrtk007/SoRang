CREATE TABLE IF NOT EXISTS `team15`.`AlcoholTable` (
    `tab_no` INT(5) NOT NULL,
    `tab_name` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`tab_no`)
)