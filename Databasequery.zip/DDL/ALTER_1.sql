ALTER TABLE `Beer` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Liquor` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Nonalcohol` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Wine` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Cocktail` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Etc` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Makgeolli` ADD `table_no` INT(5) NOT NULL;
ALTER TABLE `Soju` ADD `table_no` INT(5) NOT NULL;


